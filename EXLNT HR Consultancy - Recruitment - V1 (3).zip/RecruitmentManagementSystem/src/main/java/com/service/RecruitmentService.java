package com.service;

import java.util.ArrayList;
import com.model.CandidateInfo;

import org.springframework.stereotype.Service;
import com.exception.InvalidCandidateException;

//use appropriate annotation to configure ElectricityService as a Service
@Service
public class RecruitmentService {
	
	private ArrayList<CandidateInfo> candidateList = new ArrayList<>();
	
	//add CandidateInfo object to candidateList
	public boolean addCandidate(CandidateInfo candidate)  throws InvalidCandidateException{
		
		if(getCandidateByEmailId(candidate.getEmailId())==null) {
			candidateList.add(candidate);
			return true;
		}
		else {throw new InvalidCandidateException("Candidate "+candidate.getName()+" has already registered");}
		
	}
	
	//Fetch CandidateInfo for a given emailId
	public CandidateInfo getCandidateByEmailId(String emailId) {
		
		//fill code
		CandidateInfo obj1=null;
		for(CandidateInfo obj: candidateList) {
			if(obj.getEmailId().equalsIgnoreCase(emailId)) {					 
					obj1= obj;	
			 }
			}		
			return obj1;
		
	}	 	  	  		    	   	 	   	 	
	
	//To get information about all CandidateInfo
	public ArrayList<CandidateInfo> viewAllCandidates() {
			return candidateList;
		
	}

	public ArrayList<CandidateInfo> getCandidateList() {
		return candidateList;
	}

	public void setCandidateList(ArrayList<CandidateInfo> candidateList) {
		this.candidateList = candidateList;
	}
	
	

}
