package com.controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.model.CandidateInfo;
import com.service.RecruitmentService;

import com.exception.InvalidCandidateException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import java.util.ArrayList;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//use appropriate annotation to configure BookController as Controller
@Controller
public class RecruitmentController {
	
		@Autowired
	private RecruitmentService recruitmentService;
	
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String showIndex() {		
		return "index";
	}
		@ModelAttribute("designation")	
	public  ArrayList<String> populateDesignation(){		
		ArrayList<String> designation = new ArrayList<String>();
		designation.add("Project Manager");
		designation.add("Team Lead");
		designation.add("Developer");
		designation.add("Tester");
		designation.add("Administrator");
		designation.add("Accountant");
	
		return designation;                     
		
	}	 	  	  		    	   	 	   	 	
		@RequestMapping(value = "/showRegisterCandidate", method = RequestMethod.GET)
	public String showRegisterCandidatePage(@ModelAttribute("candidate") CandidateInfo candidate) {
		
		//fill code
		return "registerCandidate";
		
	}
	
		@RequestMapping(value = "/registerCandidate", method = RequestMethod.POST)
	public String addCandidateToList(@ModelAttribute("candidate") @Valid CandidateInfo candidate,BindingResult result,ModelMap model) throws InvalidCandidateException{
		
	if(result.hasErrors()){
			return ("registerCandidate");
		}
		else{		
					boolean flag=recruitmentService.addCandidate(candidate);
			if (flag){model.addAttribute("status", "Registration done successfully");}
			else {model.addAttribute("status", "");}
		
		}
		 		
		return ("registerCandidate");
		
	}
	
		@RequestMapping(value = "/viewAllCandidate", method = RequestMethod.GET)
	public String viewAllCandidateInfo(ModelMap model) {
		
			ArrayList<CandidateInfo> list=	recruitmentService.viewAllCandidates();
			model.addAttribute("candidate",list);
			return "viewAllCandidate";
		
	}
	
	@ExceptionHandler(InvalidCandidateException. class)
	public ModelAndView exceptionHandler(Exception e) {	 	  	  		    	   	 	   	 	
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("message", e.getMessage());
		mav.setViewName("exceptionPage");
		return mav;
	}

}
