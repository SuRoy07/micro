package com.exception;

public class InvalidCandidateException extends Exception {
	
	public InvalidCandidateException(String message)
	{
	super(message);
	}

}
