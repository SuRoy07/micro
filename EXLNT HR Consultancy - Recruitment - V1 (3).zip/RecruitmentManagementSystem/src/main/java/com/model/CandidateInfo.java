package com.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Min;

import org.springframework.stereotype.Component;

@Component
public class CandidateInfo {
	
	@Min(value=1,message="{error.candidateId}")
	private int candidateId;
    @NotEmpty(message="{error.name}")
	private String name;
	@NotEmpty(message="{error.emailId}")
	private String emailId;
	
	private String designation;
	@Min(value=1,message="{error.yearsOfExperience}")
	private int yearsOfExperience;
	@Min(value=9999,message="{error.expectedSalary}")
	private double expectedSalary;
	
	public CandidateInfo() {
		
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getName() {
		return name;
	}	 	  	  		    	   	 	   	 	

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public double getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(double expectedSalary) {
		this.expectedSalary = expectedSalary;
	}	 	  	  		    	   	 	   	 	

}
