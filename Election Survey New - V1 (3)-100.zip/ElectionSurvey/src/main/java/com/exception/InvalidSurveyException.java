package com.exception;

public class InvalidSurveyException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidSurveyException(String msg) {
        super(msg);
    }
}