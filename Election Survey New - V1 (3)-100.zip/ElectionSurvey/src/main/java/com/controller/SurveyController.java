package com.controller;

import java.util.ArrayList;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import com.exception.InvalidSurveyException;
import com.model.Survey;
import com.service.SurveyService;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SurveyController {

    @Autowired
    private SurveyService service;

    @RequestMapping(value = "/showPage", method = RequestMethod.GET)
    public String showPage(@ModelAttribute("survey") Survey survey) {
        return "showPage";
    }

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String showIndex() {
        return "index";
    }

    @ModelAttribute("rating")
    public ArrayList<String> populateRating() {
        ArrayList<String> rating = new ArrayList<>();
        rating.add("0");
        rating.add("1");
        rating.add("2");
        rating.add("3");
        rating.add("4");
        rating.add("5");
        return rating;
    }

    @RequestMapping(value = "/submitSurvey", method = RequestMethod.GET)
    public String submitSurvey(@ModelAttribute("survey") @Valid Survey survey, BindingResult result, ModelMap model) throws InvalidSurveyException {
        String str="showPage";
        if (result.hasErrors()) {
         //   return str;
        } else {
            System.out.println("inside add");
            boolean flag = service.submitSurvey(survey);
            if (flag) {
                model.addAttribute("status", "Your rating submitted successfully.");
            } else {
                model.addAttribute("status", "Submission failed.");
            }
            // return str;
        }
         return str;
    }

    @RequestMapping(value = "/viewReport", method = RequestMethod.GET)
    public String viewReport(ModelMap model) {
        Survey obj = service.viewReport();
        model.addAttribute("report", obj);
        return "viewReport";
    }

    @ExceptionHandler(InvalidSurveyException.class)
    public ModelAndView exceptionHandler(Exception e) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("message", e.getMessage());
        mav.setViewName("exceptionPage");
        return mav;
    }
}