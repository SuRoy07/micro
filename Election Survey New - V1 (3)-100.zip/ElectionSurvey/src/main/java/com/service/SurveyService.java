package com.service;

import java.util.ArrayList;
import org.springframework.stereotype.Service;

import com.exception.InvalidSurveyException;

//import com.exception.InvalidSponserException;

import com.model.Survey;

//use appropriate annotation to configure ElectricityService as a Service
@Service
public class SurveyService {
	private ArrayList<Survey> surveyList=new ArrayList<Survey>();
	
	//add sponser object into the sponser list
	public boolean submitSurvey(Survey survey)  throws InvalidSurveyException{	
		
	if(getSurveyFromList(survey.getEmailId())==null) {
			System.out.println("inside if");
		surveyList.add(survey);
		
		
	  }
		else {
		    throw new InvalidSurveyException("Sorry!! Already "+survey.getEmailId()+" have submitted the survey.");
		}
	return true;
	}
//Fetch the Survey object by using sponserName
	public Survey getSurveyFromList(String emailid) { 
		
		Survey obj1=null;
		for(Survey obj: surveyList) {
			if(obj.getEmailId().equalsIgnoreCase(emailid)) {					 
					obj1= obj;	
			 }
			}	 	  	  		    	   	 	   	 	
			return obj1;
	}
	
	public Survey viewReport(){
		float bjp=0,congress=0,others=0;
		for(int i=0;i<surveyList.size();i++) {
			bjp=bjp+surveyList.get(i).getRatingForBKJ();
			congress=congress+surveyList.get(i).getRatingForCFG();
			others=others+surveyList.get(i).getRatingForOthers();
		}
		Survey obj= new Survey();
		obj.setRatingForBKJ(bjp/surveyList.size());
		obj.setRatingForCFG(congress/surveyList.size());
		obj.setRatingForOthers(others/surveyList.size());
		return obj;
	}

	public ArrayList<Survey> getSurveyList() {
		return surveyList;
	}

	public void setSurveyList(ArrayList<Survey> surveyList) {
		this.surveyList = surveyList;
	}
	

}