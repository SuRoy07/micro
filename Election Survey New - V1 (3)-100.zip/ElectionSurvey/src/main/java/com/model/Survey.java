package com.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Email;
import org.springframework.stereotype.Component;

@Component
public class Survey {
	@NotEmpty(message="{error.name}")
private String name;
	@NotEmpty(message="{error.emailId.notempty}")
	@Email(message= "{error.emailId.valid}")
private String emailId;
private float ratingForBKJ;
private float ratingForCFG;
private float ratingForOthers;
public String getName() {
	return name;
}

public float getRatingForBKJ() {
	return ratingForBKJ;
}

public void setRatingForBKJ(float ratingForBKJ) {
	this.ratingForBKJ = ratingForBKJ;
}

public float getRatingForCFG() {
	return ratingForCFG;
}

public void setRatingForCFG(float ratingForCFG) {
	this.ratingForCFG = ratingForCFG;
}

public float getRatingForOthers() {	 	  	  		    	   	 	   	 	
	return ratingForOthers;
}
public void setRatingForOthers(float ratingForOthers) {
	this.ratingForOthers = ratingForOthers;
}
public void setName(String name) {
	this.name = name;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}


}