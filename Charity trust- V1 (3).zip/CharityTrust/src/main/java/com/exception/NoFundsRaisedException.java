package com.exception;

public class NoFundsRaisedException extends Exception {
	private static final long serialVersionUID = 1L;

	public NoFundsRaisedException(String msg) {
		// fill the code
		super(msg);
	}

}
