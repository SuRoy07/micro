package com.controller;

import java.util.ArrayList;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import com.exception.NoFundsRaisedException;
//import com.exception.
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.model.Sponsor;
import com.service.CharityService;

//use appropriate annotation to configure CharityController as Controller
@Controller
public class CharityController {

	// use appropriate annotation
	@Autowired
	private CharityService service;
    
    @RequestMapping(value="/showPage",method=RequestMethod.GET)
    public String showPage(@ModelAttribute("donate") Sponsor book){
        return "showPage";
    }
    
    @RequestMapping(value="/index",method=RequestMethod.GET)
    public String showIndex(){
        return "index";
    }
    
    @ModelAttribute("donationFor")
    public ArrayList<String> populateDonationList(){
        ArrayList<String> fundList=new ArrayList<String>();
        fundList.add("Education");
        fundList.add("Food");
        fundList.add("Medicine");
        fundList.add("Cloth");
        fundList.add("MedicalExpense");
        
        return fundList;
    }
	// invoke the service class - addFundDetails method.
	@RequestMapping(value="/addFund", method=RequestMethod.POST)
	public String addFundDetails(@ModelAttribute("donate") @Valid Sponsor sponsor, BindingResult result, ModelMap model) {

		// Fill the code
		if(result.hasErrors()){
		    
		}else{
		    System.out.println("inside add");
		    boolean flag=service.addFundDetails(sponsor);
		    if(flag){
		        model.addAttribute("status","Thank you"+sponsor.getSponsorName()+",Happy for your donation towards our charity for better service");
		    }else{
		        model.addAttribute("status","");
		    }
		}

		return "showPage";
	}

	// invoke the service class - viewFundList method.
	@RequestMapping(value="/viewList",method=RequestMethod.GET)
	public String viewFundList(ModelMap model) throws NoFundsRaisedException{
		// Fill the code
        ArrayList<Sponsor> list = service.viewFundList();
        model.addAttribute("list",list);
		return "viewList";

	}

	// Use appropriate annotation
	@ExceptionHandler(NoFundsRaisedException.class)
	public ModelAndView exceptionHandler(Exception e) {

		// Fill the code
		ModelAndView mav=new ModelAndView();
		mav.addObject("message",e.getMessage());
		mav.setViewName("exceptionPage");
		return mav;

	}

}





