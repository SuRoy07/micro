package com.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Min;

import org.springframework.stereotype.Component;
//POJO class
// Use appropriate annotation
@Component
public class Sponsor {
	
	// Fill the code
	@NotEmpty(message="{error.sponsorName}")
	private String sponsorName;
	
	//Fill the code
	@Min(value=1,message="{error.amount}")
	private float amount;
	
	//fill the code
	@NotEmpty(message="{error.date}")
	private String date;
	
	private String donationFor;
	
	//Fill the code
	@NotEmpty(message="{error.phoneNumber}")
	private String phoneNumber;

	public String getSponsorName() {
		return sponsorName;
	}

	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDonationFor() {
		return donationFor;
	}

	public void setDonationFor(String donationFor) {
		this.donationFor = donationFor;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
